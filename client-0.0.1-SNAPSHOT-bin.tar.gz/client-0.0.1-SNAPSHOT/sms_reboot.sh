#!/bin/sh
sudo cp /home/pi/piClient/client/12d1:1f01_hilink /etc/usb_modeswitch.d/12d1:1f01
reboot
#from=$SMS_1_NUMBER
#sudo leafpad tmp.txt 
